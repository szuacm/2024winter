#include <bits/stdc++.h>
#define int long long

using namespace std;

int n,p;
int inv[50000010];

inline int read(){
	int x=0,tag=1;
	char c=getchar();
	for (;!isdigit(c);c=getchar()) if (c=='-') tag=-1;
	for (;isdigit(c);c=getchar()) x=(x<<1)+(x<<3)+c-'0';
	return x*tag;
}

signed main(){
	n=read(),p=read();
	inv[1]=1,puts("1");
	for (int i=2;i<=n;i++){
		inv[i]=(p-p/i)*inv[p%i]%p;
		printf("%lld\n",inv[i]);
	}
	return 0;
}