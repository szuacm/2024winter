#include <bits/stdc++.h>
#define int long long

using namespace std;

inline int read(){
    int x=0,tag=1;
    char c=getchar();
    for (;!isdigit(c);c=getchar()) if (c=='-') tag=-1;
    for (;isdigit(c);c=getchar()) x=(x<<1)+(x<<3)+c-'0';
    return x*tag;
}

void exgcd(int a,int b,int &x,int &y){
	if (!b) x=1,y=0;
	else exgcd(b,a%b,y,x),y-=a/b*x;
}

signed main(){
    int n,p,k;
    n=read(),p=read(),k=read();
    vector<int> a(n+1),s(n+1),sv(n+1);
    s[0]=1;
    for (int i=1;i<=n;i++){
        a[i]=read();
        s[i]=(s[i-1]*a[i])%p;
    }
    int _;
    exgcd(s[n],p,sv[n],_);
    sv[n]=(sv[n]%p+p)%p;
    for (int i=n-1;i;i--){
        sv[i]=sv[i+1]*a[i+1]%p;
    }
    int nowk=k,ans=0;
    for (int i=1;i<=n;i++){
        (ans+=nowk*s[i-1]%p*sv[i]%p)%=p;
        (nowk*=k)%=p;
    }
    cout<<ans<<'\n';
	return 0;
}