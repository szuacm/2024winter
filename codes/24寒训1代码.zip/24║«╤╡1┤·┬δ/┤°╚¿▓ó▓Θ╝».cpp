#include<bits/stdc++.h>
using namespace std;
typedef double db;
#define int long long
#define endl "\n"
#define fi first
#define se second
typedef long long ll;
typedef pair<int, int> pii;
const int mod = 998244353;
const int N = 5e3 + 10;
typedef array<int, 3> arr;

void QAQ(){
    int n, m;
    cin >> n >> m;
    vector<int> fa(n + 1), d(n + 1);
    iota(fa.begin(), fa.end(), 0);
//===========================================================================
    //����ǲ���Ҫȡģ�Ĳ��鼯����ά�����룩��ֻ��Ҫ��add�е�ģ��ģȥ���Ϳ����ˣ�ע��ֱ�u->v
    auto find = [&] (auto find, int x) -> int{
        if(fa[x] != x){
            int t = find(find, fa[x]);
            d[x] = d[fa[x]] + d[x];
            fa[x] = t;
        }
        return fa[x];
    };
    auto add = [&] (int u, int v, int c) -> void {
        int uu = find(find, u), vv = find(find, v);
        fa[uu] = vv;
        d[uu] = ((d[v] - d[u] - c) % 3 + 3) % 3;
    };
//===========================================================================
    int cnt = 0;
    for(int i = 1; i <= m; i ++){
        int op, x, y;
        cin >> op >> x >> y;
        if(x > n || x < 1 || y > n || y < 1){
            cnt ++;
        }
        else if(op == 1){
            int xx = find(find, x), yy = find(find, y);
            if(xx == yy){
                if((d[y] - d[x]) % 3) cnt ++;
            }
            else{
                add(x, y, 0);
            }
        }
        else if(op == 2){
            int xx = find(find, x), yy = find(find, y);
            if(xx == yy){
                if((d[y] - d[x] - 1) % 3) cnt ++;
                //����ǽ���ȡģ�����ϵ�����԰����۾���һ��������Լ���ȡģ������Ӱ��
            }
            else{
                add(x, y, 1);
            }
        }  
        else assert(0);
    }
    cout << cnt << endl;
}


signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int t = 1;
//	cin >> t;
	while(t --) {
		QAQ();
	}
	return 0;
}
