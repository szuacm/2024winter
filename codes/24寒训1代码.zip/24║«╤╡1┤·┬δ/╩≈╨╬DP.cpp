#include<bits/stdc++.h>
using namespace std;
typedef double db;
#define int long long
#define endl "\n"
#define fi first
#define se second
typedef long long ll;
typedef pair<int, int> pii;
const int mod = 998244353;
const int N = 5e3 + 10;
typedef array<int, 3> arr;

void QAQ() {
	int n;
	cin >> n;
	vector<int> num(n + 1);
	for(int i = 1; i <= n; i ++){
		cin >> num[i];
	} 
	vector<vector<int>> e(n + 1);
	vector<int> in(n + 1);
	for(int i = 1; i < n; i ++){
		int v, u;
		cin >> v >> u;
		e[u].push_back(v);
		in[v]++;
	}
	
	vector<vector<int>> dp(n + 1, vector<int>(2));
	vector<int> vis(n + 1); 
	
	for(int i = 1; i <= n; i ++){
		dp[i][1] = num[i];
	}
	
	auto dfs = [&](auto dfs, int u) -> void {
		if(vis[u]) return ;
		//��ǵ�ǰ���߹� 
		vis[u] = 1;
		for(auto v : e[u]){
			//���ߵ�Ҷ�ӽڵ㣬���ϻ��� 
			dfs(dfs, v);
			dp[u][0] += max(dp[v][1], dp[v][0]);
			dp[u][1] += dp[v][0];
		}
	};
	
	
	for(int i = 1; i <= n; i ++){
		if(in[i] == 0){
			dfs(dfs, i);
			cout << max(dp[i][0], dp[i][1]);
		}
	}
}


signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int t = 1;
//	cin >> t;
	while(t --) {
		QAQ();
	}
	return 0;
}
