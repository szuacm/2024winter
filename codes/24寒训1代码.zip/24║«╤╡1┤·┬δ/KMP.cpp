#include<bits/stdc++.h>
using namespace std;
typedef double db;
#define int long long
#define endl "\n"
#define fi first
#define se second
typedef long long ll;
typedef pair<int, int> pii;
const int mod = 998244353;
const int N = 5e3 + 10;
typedef array<int, 3> arr;

void QAQ(){
	string s, p;
	cin >> s >> p;
	int n = p.size(), m = s.size();
	p = " " + p, s = " " + s;
	vector<int> nxt(n + 1);
	for(int i = 2, j = 0; i <= n; i ++){
		//ע��ӵڶ�����ʼƥ�� 
		while(j && p[i] != p[j + 1]) j = nxt[j];
		if(p[i] == p[j + 1]) j ++;
		nxt[i] = j;
	}
	
	for(int i = 1, j = 0; i <= m; i ++){
		while(j && s[i] != p[j + 1]) j = nxt[j];
		if(s[i] == p[j + 1]) j ++;
		if(j == n){
			cout << i - n + 1 << endl;
		}
	} 
	
	for(int i = 1; i <= n; i ++){
		cout << nxt[i] << " ";
	}
	cout << endl;
}


signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int t = 1;
//	cin >> t;
	while(t --) {
		QAQ();
	}
	return 0;
}
