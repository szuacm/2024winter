#include<bits/stdc++.h>
using namespace std;
typedef double db;
#define int long long
#define endl "\n"
#define fi first
#define se second
typedef long long ll;
typedef pair<int, int> pii;
const int mod = 998244353;
const int N = 5e3 + 10;
typedef array<int, 3> arr;

void QAQ() {
	int n;
	cin >> n;
	vector<int> num(n * 2 + 1), sum(n * 2 + 1);
	for(int i = 1; i <= n; i ++){
		cin >> num[i];
		//�����γɻ� 
		num[i + n] = num[i];
	}
	//dp[i][j]  �ϲ���i��j   ��С�÷� 
	vector<vector<int>> minn(n * 2 + 1, vector<int>(n * 2 + 1, 0x3f3f3f3f)),
						maxx(n * 2 + 1, vector<int>(n * 2 + 1));
	for(int i = 1; i <= n * 2; i ++){
		//���ټ�������ͣ�����ʹ��ǰ׺�ͼ��� 
		sum[i] = sum[i - 1] + num[i];
		minn[i][i] = 0;
	}
	
	for(int len = 1; len <= n; len ++){//ö�ٵ�ǰ�ϲ�����ĳ��� 
		for(int i = 1; i + len <= 2 * n; i ++){//ö�ٵ�ǰ�������� 
			for(int k = i; k < i + len; k ++){//ö�ٵ�ǰ����Ķϵ� 
				int j = i + len;
				minn[i][j] = min(minn[i][j], minn[i][k] + minn[k + 1][j] + sum[j] - sum[i - 1]); 
				maxx[i][j] = max(maxx[i][j], maxx[i][k] + maxx[k + 1][j] + sum[j] - sum[i - 1]);
			}
		} 
	}
	int ans = 0x3f3f3f3f;
	for(int i = 1; i <= n; i ++){
		ans = min(ans, minn[i][i + n - 1]);
	}
	cout << ans << endl;
	ans = 0;
	for(int i = 1; i <= n; i ++){
		ans = max(ans, maxx[i][i + n - 1]);
	}
	cout << ans << endl;
}


signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int t = 1;
//	cin >> t;
	while(t --) {
		QAQ();
	}
	return 0;
}
