#include<bits/stdc++.h>
using namespace std;
typedef double db;
#define int long long
#define endl "\n"
#define fi first
#define se second
typedef long long ll;
typedef pair<int, int> pii;
const int mod = 998244353;
const int N = 5e3 + 10;
typedef array<int, 3> arr;

void QAQ(){
	int n, m, s;
	cin >> n >> m >> s;
	vector<int> dep(n + 1);
	vector<vector<int>> e(n + 1), fa(22, vector<int>(n + 1));
	for(int i = 1; i < n; i ++){
		int a, b;
		cin >> a >> b;
		e[a].push_back(b);
		e[b].push_back(a); 
	} 
	auto init = [&]() -> void {
		vector<int> vis(n + 1);
		auto dfs = [&](auto dfs, int u) -> void {
			vis[u] = 1;
			for(auto v : e[u]){
				if(vis[v]) continue;
				dep[v] = dep[u] + 1;
				// ��2 ^ 0������ 
				fa[0][v] = u;
				dfs(dfs, v); 
			}
		};
		dfs(dfs, s);
		
		for(int i = 1; i < 22; i ++){
			for(int j = 1; j <= n; j ++){
				fa[i][j] = fa[i - 1][fa[i - 1][j]];
			}
		}
		
	};
	
	init();
	
	auto LCA = [&](int x, int y) -> int {
		//Ĭ��depx > depy
		if(dep[x] < dep[y]) swap(x, y);
		while(dep[x] > dep[y]){
			//gap = dep[x] - dep[y] 
			//(int)log2(gap)   ǿת��int Ĭ����ȡ�� 
			x = fa[(int)log2(dep[x] - dep[y])][x]; 
		}
		if(x == y){
			return x;
		} 
		for(int i = log2(dep[x]); i >= 0; i --){
			if(fa[i][x] != fa[i][y]){
				x = fa[i][x], y = fa[i][y];
			}
		}
		return fa[0][x];
	};
	
	for(int i = 1; i <= m; i ++){
		int x, y;
		cin >> x >> y;
		cout << LCA(x, y) << endl;
	}
}


signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int t = 1;
//	cin >> t;
	while(t --) {
		QAQ();
	}
	return 0;
}
